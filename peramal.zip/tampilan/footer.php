<!-- Footer -->
<footer class="container-fluid bg-4 text-center">
  <p>Dibuat Oleh <a href="http://fb.com/dion.aryapamungkas">&copy;Dion Arya Pamungkas</a></p>
<p>Jangan Terlalu serius ini cuma bercanda</p>
</footer>

</body>
</html>
